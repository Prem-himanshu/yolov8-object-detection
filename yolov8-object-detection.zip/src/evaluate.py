from ultralytics import YOLO

model = YOLO("runs/detect/yolov8_project/weights/best.pt")

metrics = model.val()

print("mAP50:", metrics.box.map50)
print("mAP50-95:", metrics.box.map)
print("Precision:", metrics.box.precision)
print("Recall:", metrics.box.recall)
