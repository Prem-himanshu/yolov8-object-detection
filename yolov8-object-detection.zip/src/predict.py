from ultralytics import YOLO

model = YOLO("runs/detect/yolov8_project/weights/best.pt")

# Image prediction
model("test.jpg", save=True)

# Webcam
model.predict(source=0, show=True)
