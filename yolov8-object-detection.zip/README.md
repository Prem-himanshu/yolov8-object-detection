# YOLOv8 Object Detection Project

## Overview
Real-time object detection using YOLOv8 for images, videos, and webcam.

## Installation
pip install -r requirements.txt

## Training
python src/train.py

## Prediction
python src/predict.py

## Evaluation
python src/evaluate.py

## Dataset Format
YOLO format:
class_id x_center y_center width height

## Outputs
Annotated images and videos saved automatically.
